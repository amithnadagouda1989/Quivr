import type { Schema, Attribute } from '@strapi/strapi';

declare module '@strapi/strapi' {
  export module Shared {}
}
