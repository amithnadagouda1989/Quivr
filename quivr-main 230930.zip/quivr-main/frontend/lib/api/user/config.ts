export const USER_IDENTITY_DATA_KEY = "user-identity-data";
export const USER_DATA_KEY = "user-data";
