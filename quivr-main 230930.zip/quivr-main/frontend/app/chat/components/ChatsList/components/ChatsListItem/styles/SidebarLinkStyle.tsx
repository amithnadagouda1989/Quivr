export const sidebarLinkStyle =
  "w-full rounded-2xl px-5 py-2 text-base flex justify-start items-center gap-4 bg-gray-100 dark:bg-black/10 hover:bg-gray-200 dark:hover:bg-black/20 focus:outline-none";
